
# ItinerAI Starter Repository

Questo repository contiene un semplice progetto **Next.js 14** pronto per il deploy su **Cloudflare Pages** o **Vercel**.

## Comandi utili

```bash
npm install      # Installa le dipendenze
npm run dev      # Avvia in locale (http://localhost:3000)
npm run build    # Compila in modalità statica (cartella 'out')
```
